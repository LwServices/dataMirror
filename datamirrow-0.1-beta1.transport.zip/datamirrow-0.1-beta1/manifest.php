<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e68e18c2821a6fec575f5011df85e159',
      'native_key' => 'datamirrow',
      'filename' => 'modNamespace/f52b0e21b79f68c6f2951dcc9d0f5386.vehicle',
      'namespace' => 'datamirrow',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'af6c9dab1b49883e65dc2ff3d918bb6c',
      'native_key' => 7,
      'filename' => 'modPlugin/f03f306432020675be5194ba64224ad4.vehicle',
      'namespace' => 'datamirrow',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c437f0f3d58f58a98f8326ed5ebf8fbd',
      'native_key' => 1,
      'filename' => 'modCategory/bfec6144a7ba1969deddabe76a727ebc.vehicle',
      'namespace' => 'datamirrow',
    ),
  ),
);